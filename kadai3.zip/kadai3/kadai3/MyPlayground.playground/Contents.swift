import UIKit

var label1:String
var label2:String
var label3:String

label1 = "-"
label2 = "101010"

label3 = label1 + label2
type(of: label3)
var label3_type = type(of: label3)
var a:Int

if label3_type == String.Type.self {
        a = 5
    }else{
        a = 3
    }

let actionSheet = UIAlertController(
    title: "ShinanActionSheet", message: "どちらを選びますか？", preferredStyle: .actionSheet)

let actionA = UIAlertAction(
    title: "選択肢A", style: .default, handler: {action in print("選択肢Aが選ばれました")})
actionSheet.addAction(actionA)


