//
//  ViewController.swift
//  kadai3
//
//  Created by 白鳥貢 on 2020/07/25.
//  Copyright © 2020 mitsugu.shiratori. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
 
    @IBOutlet weak var leftTextField: UITextField!
    @IBOutlet weak var rightTextField: UITextField!
    @IBOutlet weak var leftSwitch: UISwitch!
    @IBOutlet weak var rightSwitch: UISwitch!
    @IBOutlet weak var leftLabel: UILabel!
    @IBOutlet weak var rightLabel: UILabel!
    @IBOutlet weak var totalLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func pressCheck(_ sender: Any) {
        //テキストフィールドの入力チェック
        let value1 = Int(leftTextField.text ?? "") ?? 0
        let value2 = Int(rightTextField.text ?? "") ?? 0

        if value1|value2 < 0 {
            let title = "負の値は入力しないでください"
            let message = "再度入力してください"
            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
            
            let ok = UIAlertAction(title: "OK", style: .default, handler:nil)
            alert.addAction(ok)
        }
    }
        
    @IBAction func pressButton(_ sender: Any) {
        //ラベルへの変換
        let minuslabel = "-"
        
        if leftSwitch.isOn {
            leftLabel.text = leftTextField.text
        }else{
            leftLabel.text = minuslabel + String(leftTextField.text ?? "")
        }
        
        if rightSwitch.isOn {
            rightLabel.text = rightTextField.text
        }else{
            rightLabel.text = minuslabel + String(rightTextField.text ?? "")
        }
        
        //計算
        let num1 = Int(leftLabel.text ?? "") ?? 0
        let num2 = Int(rightLabel.text ?? "") ?? 0

        //出力
        totalLabel.text = String(num1 + num2)
    }
}

