# kadai3
